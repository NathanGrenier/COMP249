public interface Comparison {

    abstract boolean topRank(Object obj);

    abstract boolean lowRank(Object obj);
}
